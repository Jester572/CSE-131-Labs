# 1. Name:
#      Jesse Earley 
# 2. Assignment Name:
#      Lab 05 : Sudoku Draft
# 3. Assignment Description:
#      This program takes a soduku game from a json and prints it on the screen
#       You can chose a spot to add a number and save your game
# 4. What was the hardest part? Be as specific as possible.
#      The hardest part was trying to figure out how to best display the board from the json.
#       It has been a while since I have had to use json in python so I had to go learn it again.
# 5. How long did it take for you to complete the assignment?
#      3 Hours

import json

def main():
    game_over = False
    board = read_board()
    
    while not game_over:        
        display_board(board)
        if play_round(board) == "Q":
            game_over = True
    

def display_board(board):
    print('   A B C D E F G H I')
    for i in range(9):
        if i % 3 == 0 and i != 0 :
            print('   -----+-----+-----')
        row = '{}  {} {} {}|{} {} {}|{} {} {}'
        print(row.format(i + 1, board[i][0],board[i][1],board[i][2],board[i][3],board[i][4],board[i][5],board[i][6],board[i][7],board[i][8]))
        

def read_board():
    print('Welcome to Sudoku!\n'
          'Please Select from the following the desired difficulty\n'
          '1: Easy\n'
          '2: Medium\n'
          '3: Hard\n'
          '4: Previously saved game')
    selection = int(input('Selection: '))
    
    if selection == 1 :
        game_file = '131.05.Easy.json'
    elif selection == 2:
        game_file = '131.05.Medium.json'
    elif selection == 3:
        game_file = '131.05.Hard.json'
    elif selection == 4:
        game_file = 'saved_game.json'

    f = open(game_file, "r")
    data = json.loads(f.read())
    board = data["board"]
    f.close()
    x_index = 0
    
    #Iterates through each number and changes it from a zero to a space
    for x in board:
        y_index = 0
        for y in x:
            if y == 0:
                board[x_index][y_index] = " "
            y_index += 1
        x_index += 1
        
    return board

def play_round(board):
    coordinates = get_coordinate(board)
    if coordinates == 'Q':
        return coordinates
    row = coordinates[1]
    column = coordinates[0]
    row_index = int(coordinates[1]) - 1
    valid_num = False
    while not valid_num:
        number = int(input(f'What number goes in {column}{row}: '))
        valid_num = validate_number(number)
    if column == "A":
        column_index = 0
    elif column == "B":
        column_index = 1
    elif column == "C":
        column_index = 2
    elif column == "D":
        column_index = 3
    elif column == "E":
        column_index = 4
    elif column == "F":
        column_index = 5
    elif column == "G":
        column_index = 6
    elif column == "H":
        column_index = 7
    elif column == "I":
        column_index = 8
    board[row_index][column_index] = number
    return board
    

def get_coordinate(board):
    valid_coordinate = False
    while not valid_coordinate:        
        coordinate = input('\nSpecify a coordinate to edit or \'Q\' to save and quit Example \'B2\': ')
        #checks to make sure there is a Letter number pair 
        if len(coordinate) > 2 or len(coordinate) < 1:
            print(f'{coordinate[1]} is not a valid row Select a row between 1 and 9\n')
            continue 
        if coordinate == "Q":
            write_board(board)
            return coordinate
        #validate coordinates
        row = coordinate[1]
        column = coordinate[0]
        if validate_number(row):
            if column < 'J':
                valid_coordinate = True
            else:
                print(f'{column} is not a valid column Select a column between A and I\n')
        else:
                print(f'{row} is not a valid row Select a row between 1 and 9\n')
    return column, row

def validate_number(number):
    if int(number) > 9 or int(number) < 1:
        print('Please select a number between 1 and 9: ')
        return
    else:
        return True

def write_board(board):
    #Iterates through each number and changes it from a space to a zero
    x_index = 0
    for x in board:
        y_index = 0
        for y in x:
            if y == " ":
                board[x_index][y_index] = 0
            y_index += 1
        x_index += 1
        
    board = {"board":board}
    data = json.dumps(board)
    f = open("saved_game.json", "w")
    f.write(data)
    f.close()

if __name__ == '__main__':
    main()